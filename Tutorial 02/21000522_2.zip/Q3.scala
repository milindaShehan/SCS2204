object XYZ{

    def main(args : Array[String]) : Unit = {

        val normal = 40; 
        val Ot  = 30;
        val sal = salary (normal , Ot );
        println(s"Salary $sal");
    }

    def salary (normal : Int, Ot: Int):Double = 
    {
        val n : Int = 250;
        val ot : Int = 85;

        val tot = n*normal + ot*Ot;
        val tax =  tot*12/100;

        tot - tax;

    }

}