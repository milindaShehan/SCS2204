object Tickets {
  def main(args: Array[String]): Unit = {
    println("The best ticket price is: Rs. " + bestPriceCalc());
  }

  def profitCalc(ticketPrice: Double): Double = {
    val initAttendance = 120;
    val initPrice = 15.0;
    val performanceCost = 500;
    val attendeeCost = 3;
    val attendanceChangeValue = 20;

    val attendance = initAttendance + (ticketPrice - initPrice) / 5 * attendanceChangeValue;
    val income = ticketPrice * attendance;
    val cost = performanceCost + attendeeCost * attendance;
    val profit = income - cost;

    profit
  }

  def bestPriceCalc(): Double = {
    val range = 10 to 30;
    var bestProfit = 0.0;
    var bestPrice = 0.0;

    for (price <- range) {
      val ticketPrice = price;
      val profit = profitCalc(ticketPrice);

      if (profit > bestProfit) {
        bestProfit = profit;
        bestPrice = ticketPrice;
      }
    }

    bestPrice
  }
}
