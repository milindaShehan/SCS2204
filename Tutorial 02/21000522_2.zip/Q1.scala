object variable {

    def main (args : Array[String]) : Unit ={
        
        var k , i , j :Int = 2;
        var m,n :Int = 5;
        var f : Float = 12.0f;
        var g : Float = 4.0f;
        var c :Char = 'X';

        println(k+12*m);
        println(m/j);
        println(n%j);
        println(m/j*j);
        println(f+10*5+g);
        i+=1;
        println(i*n);

    }




}