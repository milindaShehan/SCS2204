object Q2{

    def main (args : Array[String]) : Unit ={
        var (a,b,c,d:Int) = (2 ,3 ,4 ,5);
        var k : Float = 4.3f;
        var m,n :Int = 5;
        var f : Float = 12.0f;
        var g : Float = 4.0f;
        b-=1;
        d-=1;

        println(b*a+c*d);
        a+=1;
        println(a);
        println(-2*(g-k)+c);
        println(c+=1);
        c+=1;
        a+=1;
        c=c*a
        println(c);

    }

}